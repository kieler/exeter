import { type BatchUploadConfiguration } from './core/config';
/**
 * Configuration for an upload worker that drains batches persisted by prior
 * instrumentation sessions without registering or recording a new session.
 */
export interface PendingBatchUploadLoopOptions {
    /** Base URL of the Exeter collection API. */
    apiBaseUrl: string;
    /** Timeout applied to batch-upload requests. */
    requestTimeoutMs?: number;
    /** Controls batching, retries, and the upload-loop interval. */
    batchUpload?: Partial<BatchUploadConfiguration>;
}
/** Controls the lifecycle of a pending-batch upload worker. */
export interface PendingBatchUploadLoopHandle {
    /** Stops the loop after one final attempt to drain eligible persisted batches. */
    dispose(): Promise<void>;
}
/**
 * Starts a background worker that drains eligible batches from this origin's
 * IndexedDB queue. Batches keep their original session IDs, so this function
 * neither registers nor records an interaction session itself.
 */
export declare function startPendingBatchUploadLoop(options: PendingBatchUploadLoopOptions): Promise<PendingBatchUploadLoopHandle>;
//# sourceMappingURL=pending-batch-upload-loop.d.ts.map