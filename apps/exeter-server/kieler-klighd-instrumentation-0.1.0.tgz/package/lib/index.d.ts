import { ContainerModule } from 'inversify';
import { InitialiseOptions } from './core/config';
export { startPendingBatchUploadLoop, type PendingBatchUploadLoopHandle, type PendingBatchUploadLoopOptions, } from './pending-batch-upload-loop';
/**
 * Returned by the `initialise()` function to allow interacting with the instrumentation
 * after it was created / initialised.
 */
export interface InstrumentationHandle {
    /**
     * Reference to a Sprotty Container module that needs to be integrated with the Sprotty runtime to
     * correctly collect all (semantic) Sprotty actions / events.
     */
    module: ContainerModule;
    /**
     * Allows disposing / permanently stopping the instrumentation.
     */
    dispose(): Promise<void>;
}
/**
 * Initialises the instrumentation for immediate event collection and processing.
 */
export declare function initialise(options: InitialiseOptions): Promise<InstrumentationHandle>;
//# sourceMappingURL=index.d.ts.map