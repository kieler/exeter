import { ContainerModule } from 'inversify';
import { SprottyProducer } from './sprotty.producer';
export declare function createSprottyModule(producer: SprottyProducer): ContainerModule;
//# sourceMappingURL=sprotty-module.d.ts.map