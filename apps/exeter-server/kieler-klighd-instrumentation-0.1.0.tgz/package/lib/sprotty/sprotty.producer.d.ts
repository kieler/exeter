import { Action } from 'sprotty-protocol';
import { SModelElementImpl } from 'sprotty';
import { Collector } from '../core/collector';
import { Producer } from '../core/producer';
import { Clock } from '../core/time';
/**
 * Collects Sprotty interactions without changing how the diagram handles them.
 */
export declare class SprottyProducer implements Producer {
    private readonly clock;
    private readonly collector;
    private disposed;
    constructor(clock: Clock, collector: Collector);
    dispose(): void;
    mouse(eventType: string, target: SModelElementImpl, event: MouseEvent | WheelEvent): void;
    key(eventType: 'keyDown' | 'keyUp', target: SModelElementImpl, event: KeyboardEvent): void;
    action(action: Action): void;
    private collect;
    private targetOf;
}
//# sourceMappingURL=sprotty.producer.d.ts.map