import { MouseListener, SModelElementImpl } from 'sprotty';
import { Action } from 'sprotty-protocol';
import { SprottyProducer } from '../sprotty.producer';
export declare class SprottyMouseListener extends MouseListener {
    private readonly producer;
    constructor(producer: SprottyProducer);
    mouseOver(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseOut(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseEnter(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseLeave(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseDown(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseMove(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    mouseUp(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    wheel(target: SModelElementImpl, event: WheelEvent): (Action | Promise<Action>)[];
    doubleClick(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    contextMenu(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    dragOver(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
    drop(target: SModelElementImpl, event: MouseEvent): (Action | Promise<Action>)[];
}
//# sourceMappingURL=mouse.listener.d.ts.map