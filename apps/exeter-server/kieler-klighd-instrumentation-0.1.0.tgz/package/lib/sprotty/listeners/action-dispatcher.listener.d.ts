import { ActionDispatcher } from 'sprotty';
import { Action } from 'sprotty-protocol';
import { SprottyProducer } from '../sprotty.producer';
export declare class SprottyActionDispatcher extends ActionDispatcher {
    private readonly producer;
    constructor(producer: SprottyProducer);
    dispatch(action: Action): Promise<void>;
}
//# sourceMappingURL=action-dispatcher.listener.d.ts.map