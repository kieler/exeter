import { KeyListener, SModelElementImpl } from 'sprotty';
import { Action } from 'sprotty-protocol';
import { SprottyProducer } from '../sprotty.producer';
export declare class SprottyKeyListener extends KeyListener {
    private readonly producer;
    constructor(producer: SprottyProducer);
    keyDown(target: SModelElementImpl, event: KeyboardEvent): Action[];
    keyUp(target: SModelElementImpl, event: KeyboardEvent): Action[];
}
//# sourceMappingURL=key.listener.d.ts.map