import type { BatchUploadStore, PendingBatch } from '.';
import { SequencedInteractionEvent } from '../../../collector';
import { Clock } from '../../../time';
export declare class IndexedDbBatchUploadStore implements BatchUploadStore {
    private readonly clock;
    private readonly database;
    private readonly sessionId;
    private readonly abandonedBatchAfterMs;
    private constructor();
    static open(clock: Clock, sessionId: string, abandonedBatchAfterMs: number): Promise<IndexedDbBatchUploadStore>;
    addEvent(event: SequencedInteractionEvent): Promise<{
        activeEventCount: number;
    }>;
    sealBatch(): Promise<void>;
    claimNextBatches(input: {
        ownerId: string;
        leaseDurationMs: number;
        maxBatchCount: number;
    }): Promise<PendingBatch[]>;
    acknowledgeBatch(batch: PendingBatch): Promise<void>;
    scheduleRetry(batch: PendingBatch, nextAttemptAt: number): Promise<void>;
    private groupActiveEventRowsBySessionId;
}
//# sourceMappingURL=indexeddb.store.d.ts.map