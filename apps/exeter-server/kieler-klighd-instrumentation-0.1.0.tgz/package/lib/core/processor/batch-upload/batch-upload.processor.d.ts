import type { SequencedInteractionEvent } from '../../collector';
import { Processor } from '..';
import { BatchUploadConfiguration } from '../../config';
import { Clock } from '../../time';
import { HttpClient } from '../../http';
/**
 * This processor persists interaction events locally in a (robust) storage
 * and delivers them to the collection API in batches.
 *
 * An active batch is sealed when it reaches the configured event limit or when the periodic flush runs.
 * Sealed batches remain in the configured local store until the server acknowledges their receipt.
 */
export declare class BatchUploadProcessor implements Processor {
    private readonly clock;
    private readonly httpClient;
    private readonly store;
    private readonly apiBaseUrl;
    private readonly config;
    /**
     * We are using a storage that can potentially be shared across multiple tabs / iframes / etc. per
     * browser session. Therefore, we need to identify individual sessions for doing leases etc.
     */
    private readonly ownerId;
    /**
     * We use this `operation` promise as a sort-of "chain" to ensure events and operations
     * are processed sequentially.
     */
    private operation;
    /**
     * We use this promise as a sort of "lock" to make sure we're only ever upload-processing once at a time.
     */
    private processing;
    /**
     * Keep track if we've been disposed.
     * Todo: maybe use AbortController for this in the future?
     */
    private disposed;
    private readonly flushTimer;
    private constructor();
    /**
     * Static factory method to create an instace of a batch upload processor.
     */
    static create(sessionId: string, apiBaseUrl: string, config: BatchUploadConfiguration, clock: Clock, httpClient: HttpClient): Promise<BatchUploadProcessor>;
    /**
     * Processes a single event by enqueueing its storage to our Promise chain.
     */
    process(event: SequencedInteractionEvent): void;
    /**
     * Stops accepting events, performs one final upload attempt, and releases the timer resources.
     */
    dispose(): Promise<void>;
    /**
     * This function gets called on a regular schedule, as determined by the `flushIntervalMs` config option.
     */
    private flushAndProcess;
    private sealActiveBatch;
    private processPendingBatches;
    /**
     * Repeatedly claims and uploads `this.maxConcurrentUploads` batches until
     * no available batches remain.
     */
    private runPendingBatches;
    private uploadPendingBatch;
    private queueOperation;
    private retryDelayMs;
    private acknowledgementMatches;
}
//# sourceMappingURL=batch-upload.processor.d.ts.map