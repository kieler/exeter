import type { BatchUploadStore, PendingBatch } from '.';
import { SequencedInteractionEvent } from '../../../collector';
import { Clock } from '../../../time';
/**
 * Non-durable store for environments without IndexedDB.
 *
 * It follows the durable store's batching, lease, and retry contract, but its
 * data is lost when this JavaScript environment is destroyed.
 */
export declare class InMemoryBatchUploadStore implements BatchUploadStore {
    private readonly clock;
    private readonly sessionId;
    /**
     * Events for this store's session that have not been sealed yet.
     */
    private readonly activeEvents;
    /**
     * Sealed batches, retained until the server acknowledges their upload.
     */
    private readonly pendingBatches;
    constructor(clock: Clock, sessionId: string);
    addEvent(event: SequencedInteractionEvent): Promise<{
        activeEventCount: number;
    }>;
    sealBatch(): Promise<void>;
    claimNextBatches(input: {
        ownerId: string;
        leaseDurationMs: number;
        maxBatchCount: number;
    }): Promise<PendingBatch[]>;
    acknowledgeBatch(batch: PendingBatch): Promise<void>;
    scheduleRetry(batch: PendingBatch, nextAttemptAt: number): Promise<void>;
}
//# sourceMappingURL=in-memory.store.d.ts.map