import { Processor } from '.';
import type { SequencedInteractionEvent } from '../collector';
/**
 * Very simple processor that just outputs all events into the browser console.
 * Should only be used during development / debugging.
 */
export declare class ConsoleProcessor implements Processor {
    process(event: SequencedInteractionEvent): void;
}
//# sourceMappingURL=console.processor.d.ts.map