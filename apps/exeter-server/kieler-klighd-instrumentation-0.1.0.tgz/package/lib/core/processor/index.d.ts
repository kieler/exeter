import type { SequencedInteractionEvent } from '../collector';
export interface Processor {
    process(event: SequencedInteractionEvent): void;
}
//# sourceMappingURL=index.d.ts.map