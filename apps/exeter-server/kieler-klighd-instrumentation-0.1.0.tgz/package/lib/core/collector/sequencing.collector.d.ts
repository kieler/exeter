import { Collector } from '.';
import { InteractionEvent } from '../event';
import { Processor } from '../processor';
export declare class SequencingCollector implements Collector {
    private readonly processors;
    private nextSequence;
    constructor(processors: Processor[]);
    collect(event: InteractionEvent): void;
}
//# sourceMappingURL=sequencing.collector.d.ts.map