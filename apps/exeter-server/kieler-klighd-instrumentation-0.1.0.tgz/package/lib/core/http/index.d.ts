export interface HttpClient {
    postJson(url: string, data: object): Promise<Response>;
}
export declare class FetchHttpClient implements HttpClient {
    private readonly timeoutMs;
    constructor(timeoutMs: number);
    postJson(url: string, data: object): Promise<Response>;
}
//# sourceMappingURL=index.d.ts.map