import { HttpClient } from '../http';
export declare function registerSession(httpClient: HttpClient, apiBaseUrl: string, stimulusId: string, externalParticipantId: string | null, externalSessionId: string | null): Promise<{
    sessionId: string;
}>;
//# sourceMappingURL=index.d.ts.map