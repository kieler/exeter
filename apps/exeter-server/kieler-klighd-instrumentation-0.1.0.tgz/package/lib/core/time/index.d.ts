export interface Clock {
    now(): number;
}
export declare class RealClock implements Clock {
    now(): number;
}
export declare class FixedClock implements Clock {
    private nowMs;
    constructor(nowMs: number);
    now(): number;
    sleep(durationMs: number): void;
}
//# sourceMappingURL=index.d.ts.map