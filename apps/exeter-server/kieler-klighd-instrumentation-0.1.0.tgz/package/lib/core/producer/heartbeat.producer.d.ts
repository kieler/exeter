import { Producer } from '.';
import { Collector } from '../collector';
import { InteractionEvent } from '../event';
import { Clock } from '../time';
export interface HeartbeatEvent extends InteractionEvent {
    type: 'heartbeat';
}
export declare class HeartbeatProducer implements Producer {
    private readonly clock;
    private readonly collector;
    private readonly heartbeatIntervalMs;
    private disposed;
    private intervalHandler;
    constructor(clock: Clock, collector: Collector, heartbeatIntervalMs: number);
    tick(): void;
    dispose(): void;
}
//# sourceMappingURL=heartbeat.producer.d.ts.map