import { eventWithTime } from '@rrweb/types';
import { Producer } from '../core/producer';
import { Collector } from '../core/collector';
import { InteractionEvent } from '../core/event';
import { RrwebConfiguration } from '../core/config';
import { Clock } from '../core/time';
export interface RrwebEvent extends InteractionEvent {
    type: 'rrweb';
    data: {
        rrwebEvent: eventWithTime;
        rrwebIsCheckout: boolean | undefined;
    };
}
/**
 * Producer that sends `rrweb` events up for collection. This allows a later visual
 * replay of the user interaction session.
 */
export declare class RrwebProducer implements Producer {
    private readonly clock;
    private readonly collector;
    private readonly config;
    private disposed;
    /**
     * Function supplied by rrweb to permanently stop its recording listeners.
     */
    private readonly stopRecording;
    constructor(clock: Clock, collector: Collector, config: RrwebConfiguration);
    dispose(): void;
}
//# sourceMappingURL=rrweb.producer.d.ts.map